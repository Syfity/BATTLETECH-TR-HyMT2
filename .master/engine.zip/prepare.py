#!/usr/bin/env python3
import argparse, json, re, hashlib
from pathlib import Path
from adapters import extract, infer_format

def skip(rec,cfg):
    t=(rec.get('text') or '').strip(); k=(rec.get('key') or '').strip()
    if not t: return True
    for p in cfg.get('skip_key_prefixes',[]):
        if k.casefold().startswith(str(p).casefold()): return True
    for p in cfg.get('skip_value_prefixes',[]):
        if t.casefold().startswith(str(p).casefold()): return True
    for pat in cfg.get('skip_regex',[]):
        if re.search(pat,t): return True
    # güçlü teknik-only kayıt: harf yoksa çevirmeye gerek yok
    if not re.search(r'[A-Za-zÀ-ÖØ-öø-ÿĀ-žА-Яа-яΑ-ω一-龥ぁ-んァ-ン가-힣]',t): return True
    return False

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='config/job.json'); ap.add_argument('--out-dir',default='build'); a=ap.parse_args()
    cfg=json.load(open(a.config,encoding='utf-8')); rows=extract(cfg); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
    uniq={}; kept=0
    for r in rows:
        if skip(r,cfg): continue
        kept+=1; h=hashlib.sha256(r['text'].encode('utf-8')).hexdigest(); uniq.setdefault(h,{'h':h,'text':r['text'],'example_key':r.get('key','')})
    with (out/'work_items.jsonl').open('w',encoding='utf-8') as f:
        for o in uniq.values(): f.write(json.dumps(o,ensure_ascii=False)+'\n')
    manifest={'game_name':cfg.get('game_name'),'source_language':cfg.get('source_language'),'target_language':cfg.get('target_language','Turkish'),'format':infer_format(cfg['input_path'],cfg.get('format','auto')),'records_seen':len(rows),'records_selected':kept,'unique_texts':len(uniq),'shards':int(cfg.get('shards',40)),'input_path':cfg['input_path'],'output_path':cfg['output_path']}
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False))
if __name__=='__main__': main()
