#!/usr/bin/env python3
import argparse,json
from pathlib import Path
from adapters import apply

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='config/job.json'); ap.add_argument('--cache-dir',required=True); a=ap.parse_args(); cfg=json.load(open(a.config,encoding='utf-8')); cache={}
    for p in Path(a.cache_dir).rglob('cache-*.jsonl'):
        for ln in p.read_text(encoding='utf-8').splitlines():
            try: o=json.loads(ln); cache[o['h']]=o['tr']
            except: pass
    apply(cfg,cache,cfg['output_path']); print(f"output={cfg['output_path']} cache_entries={len(cache)}")
if __name__=='__main__': main()
