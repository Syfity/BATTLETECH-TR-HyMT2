#!/usr/bin/env python3
import argparse,json,hashlib,time,urllib.request,re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from protect import mask,unmask,remask,signature

def call(server,prompt,timeout=900):
    payload={'model':'Hy-MT2-7B','messages':[{'role':'user','content':prompt}],'temperature':0.7,'top_p':0.6,'top_k':20,'repeat_penalty':1.05,'max_tokens':4096,'stream':False}
    req=urllib.request.Request(server.rstrip('/')+'/v1/chat/completions',data=json.dumps(payload,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(req,timeout=timeout) as r: return json.loads(r.read().decode())['choices'][0]['message']['content'].strip()

def clean(x):
    x=x.strip(); x=re.sub(r'^```(?:text|turkish|tr)?\s*','',x,flags=re.I); x=re.sub(r'\s*```$','',x); x=re.sub(r'^\s*(?:Translation|Çeviri|Türkçe|Final)\s*:\s*','',x,flags=re.I); return x.strip()

def terms(text,g):
    low=text.casefold(); return '\n'.join(f'{k} -> {v}' for k,v in g.items() if k.casefold() in low)[:6000]

def one(server,text,cfg,context,glossary):
    src=cfg.get('source_language','Auto-detect source language'); tgt=cfg.get('target_language','Turkish'); masked,toks=mask(text); term=terms(text,glossary)
    base=f'''[Game Context]\n{context}\n\n[Source Language]\n{src}\n\n[Target Language]\n{tgt}\n\n[Source Text]\n{masked}\n\n[Task]\nTranslate only the player-facing source text into natural official-game-quality {tgt}. Preserve meaning, tone, gameplay values and canonical proper names. Every __LOC_PH_XXXX__ token is immutable: copy each exactly once in the same order. Do not add explanations.''' + (f'\n\n[Terminology]\n{term}' if term else '')
    draft=None; err=''
    for n in range(3):
        try:
            cand=unmask(clean(call(server,base)),toks)
            if cand and signature(cand)==signature(text): draft=cand; break
        except Exception as e: err=str(e); time.sleep(2*(n+1))
    if draft is None: return text,err or 'İlk çeviri doğrulanamadı'
    try:
        dm=remask(draft,toks)
        review=f'''[Game Context]\n{context}\n\n[Source Language]\n{src}\n[Target Language]\n{tgt}\n\n[Original Source]\n{masked}\n\n[Turkish Draft]\n{dm}\n\n[Review]\nCompare the draft against the original source. Correct mistranslations, omissions, additions, awkward machine-translation phrasing, terminology and tone. Keep all __LOC_PH_XXXX__ tokens exactly once and in the same order. Preserve canonical proper names and gameplay numbers. Output only the final {tgt} text.''' + (f'\n\n[Terminology]\n{term}' if term else '')
        fin=unmask(clean(call(server,review)),toks)
        if fin and signature(fin)==signature(text): return fin,None
        return draft,'İkinci kalite turu teknik yapıyı bozdu; doğrulanmış ilk taslak korundu'
    except Exception as e: return draft,'İkinci kalite turu çalışmadı; ilk taslak korundu: '+str(e)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='config/job.json'); ap.add_argument('--items',default='build/work_items.jsonl'); ap.add_argument('--server',default='http://127.0.0.1:8080'); ap.add_argument('--shard',type=int,required=True); ap.add_argument('--shards',type=int,required=True); ap.add_argument('--cache',required=True); ap.add_argument('--notes',required=True); ap.add_argument('--workers',type=int,default=2); a=ap.parse_args()
    cfg=json.load(open(a.config,encoding='utf-8')); context=Path(cfg.get('context_path','config/context.md')).read_text(encoding='utf-8'); glossary=json.load(open(cfg.get('glossary_path','config/glossary.json'),encoding='utf-8'))
    items=[json.loads(x) for x in Path(a.items).read_text(encoding='utf-8').splitlines() if x.strip()]; items=[x for x in items if int(x['h'][:16],16)%a.shards==a.shard]
    done={}
    p=Path(a.cache)
    if p.exists():
        for ln in p.read_text(encoding='utf-8').splitlines():
            try: o=json.loads(ln); done[o['h']]=o['tr']
            except: pass
    pending=[x for x in items if x['h'] not in done]; print(f'shard={a.shard} total={len(items)} pending={len(pending)}',flush=True)
    cf=open(a.cache,'a',encoding='utf-8'); nf=open(a.notes,'a',encoding='utf-8')
    with ThreadPoolExecutor(max_workers=max(1,a.workers)) as ex:
        fut={ex.submit(one,a.server,x['text'],cfg,context,glossary):x for x in pending}; c=0
        for f in as_completed(fut):
            x=fut[f]
            try: tr,note=f.result()
            except Exception as e: tr,note=x['text'],str(e)
            cf.write(json.dumps({'h':x['h'],'tr':tr},ensure_ascii=False)+'\n'); cf.flush()
            if note: nf.write(json.dumps({'h':x['h'],'source':x['text'],'translation':tr,'note':note},ensure_ascii=False)+'\n'); nf.flush()
            c+=1
            if c%20==0 or c==len(pending): print(f'{c}/{len(pending)}',flush=True)
    cf.close(); nf.close()
if __name__=='__main__': main()
