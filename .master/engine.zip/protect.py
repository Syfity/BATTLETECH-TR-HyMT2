#!/usr/bin/env python3
import re
CTRL='\x1f'
PATTERNS=[
 re.compile(r'https?://\S+|file://\S+',re.I),
 re.compile(r'</?[A-Za-z][^>]*>|<#[0-9A-Fa-f]{6,8}>'),
 re.compile(r'\$\{[^{}]+\}|\{\{[^{}]+\}\}|\{[^{}]+\}'),
 re.compile(r'%\d*\$?[sdifuxX]'),
 re.compile(r'\\[nrt]'),
 re.compile(r'\[\[[^\]]*?\]\]'),
 re.compile(r'\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b'),
]

def mask(text):
    toks=[]; out=text
    for rx in PATTERNS:
        def repl(m):
            i=len(toks); toks.append(m.group(0)); return f'__LOC_PH_{i:04d}__'
        out=rx.sub(repl,out)
    if CTRL in out:
        parts=out.split(CTRL); rebuilt=[]
        for i,p in enumerate(parts):
            rebuilt.append(p)
            if i<len(parts)-1:
                n=len(toks); toks.append(CTRL); rebuilt.append(f'__LOC_PH_{n:04d}__')
        out=''.join(rebuilt)
    return out,toks

def unmask(text,toks):
    out=text
    for i,t in enumerate(toks): out=out.replace(f'__LOC_PH_{i:04d}__',t)
    return out

def remask(text,toks):
    out=text
    for i,t in enumerate(toks): out=out.replace(t,f'__LOC_PH_{i:04d}__',1)
    return out

def signature(text):
    sig=[]
    for idx,rx in enumerate(PATTERNS): sig.extend((idx,x) for x in rx.findall(text))
    sig.extend(('ctrl',CTRL) for _ in range(text.count(CTRL)))
    return sorted(sig,key=lambda x:str(x))
