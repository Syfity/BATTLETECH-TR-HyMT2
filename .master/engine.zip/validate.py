#!/usr/bin/env python3
import argparse,json,hashlib,re
from pathlib import Path
from adapters import extract,structural_validate
from protect import signature

def leftover_pattern(lang):
    l=(lang or '').lower()
    if 'english' in l or l=='en': return re.compile(r'\b(?:the|and|you|your|this|that|with|from|for|not|are|is|to|of|in)\b',re.I)
    if 'german' in l or 'deutsch' in l or l=='de': return re.compile(r'\b(?:der|die|das|und|nicht|mit|für|von|ist|sind|ein|eine|zu|auf|ich|sie|wir)\b',re.I)
    return None

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='config/job.json'); ap.add_argument('--warnings',default='validation_warnings.txt'); a=ap.parse_args(); cfg=json.load(open(a.config,encoding='utf-8')); src=cfg['input_path']; out=cfg['output_path']; errs=structural_validate(cfg,src,out); warnings=[]
    # Çevrilebilir kayıtların teknik imzasını kaynak ve hedefte sıra bazında kontrol et.
    old_input=cfg['input_path']; source_recs=extract(cfg); cfg2=json.loads(json.dumps(cfg)); cfg2['input_path']=out; target_recs=extract(cfg2,target=True)
    if len(source_recs)!=len(target_recs): errs.append(f'Çevrilebilir kayıt sayısı değişti: {len(source_recs)} != {len(target_recs)}')
    pat=leftover_pattern(cfg.get('source_language'))
    for i,(s,t) in enumerate(zip(source_recs,target_recs),1):
        if signature(s['text'])!=signature(t['text']): errs.append(f'{i}: token/etiket yapısı değişti')
        if pat and s['text']!=t['text'] and pat.search(t['text']): warnings.append(f'{i}: kaynak dil parçası kalmış olabilir')
    if errs:
        print('\n'.join(errs[:500])); raise SystemExit(2)
    Path(a.warnings).write_text('\n'.join(warnings)+('\n' if warnings else ''),encoding='utf-8')
    print(f'OK structural+token validation. source_records={len(source_recs)} warnings={len(warnings)}')
if __name__=='__main__': main()
