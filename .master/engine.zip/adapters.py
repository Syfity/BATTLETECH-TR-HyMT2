#!/usr/bin/env python3
from __future__ import annotations
import csv, json, re, shutil
from pathlib import Path
from typing import Any


def infer_format(path: str, configured: str = "auto") -> str:
    if configured and configured.lower() != "auto": return configured.lower()
    ext = Path(path).suffix.lower()
    return {'.csv':'csv','.tsv':'tsv','.xlsx':'xlsx','.xlsm':'xlsx','.json':'json','.txt':'txt','.locres':'txt','.po':'po','.ini':'ini','.cfg':'ini','.xml':'xml'}.get(ext, ext.lstrip('.') or 'txt')


def _csv_dialect(path: Path, fmt: str, opts: dict):
    if fmt == 'tsv': return '\t'
    d = opts.get('delimiter','auto')
    if d and d != 'auto': return d
    sample = path.read_text(encoding=opts.get('encoding','utf-8'), errors='replace')[:65536]
    try: return csv.Sniffer().sniff(sample, delimiters=',;\t|').delimiter
    except Exception: return ','


def _col_index(ws, header_row: int, spec):
    if spec is None: return None
    if isinstance(spec, int): return spec
    for c in range(1, ws.max_column+1):
        if str(ws.cell(header_row,c).value or '').strip() == str(spec).strip(): return c
    raise ValueError(f'XLSX sütunu bulunamadı: {spec}')


def extract(config: dict, target: bool = False) -> list[dict]:
    path=Path(config['input_path']); opts=config.get('format_options',{}); fmt=infer_format(str(path),config.get('format','auto'))
    if fmt in ('csv','tsv'):
        enc=opts.get('encoding','utf-8'); delim=_csv_dialect(path,fmt,opts); src=(opts.get('target_field') if target and opts.get('target_field') else opts.get('source_field')); idf=opts.get('id_field')
        with path.open(encoding=enc,newline='') as f:
            r=csv.DictReader(f,delimiter=delim); fields=r.fieldnames or []
            if not src: src=next((x for x in fields if x != idf), None)
            if src not in fields: raise ValueError(f'Kaynak sütun bulunamadı: {src}; alanlar={fields}')
            return [{'rid':f'row:{i}','text':row.get(src,'') or '', 'key':row.get(idf,'') if idf else '', 'meta':{'row':i}} for i,row in enumerate(r, start=2)]
    if fmt == 'xlsx':
        import openpyxl
        wb=openpyxl.load_workbook(path, data_only=False, keep_vba=path.suffix.lower()=='.xlsm')
        hr=int(opts.get('header_row',1)); sheets=opts.get('sheet_names','*'); names=wb.sheetnames if sheets=='*' else list(sheets); out=[]
        for sn in names:
            ws=wb[sn]; sc=_col_index(ws,hr,(opts.get('target_column') if target and opts.get('target_column') is not None else opts.get('source_column'))); ic=_col_index(ws,hr,opts.get('id_column')) if opts.get('id_column') is not None else None
            if sc is None: raise ValueError('XLSX source_column gerekli')
            for row in range(hr+1,ws.max_row+1):
                v=ws.cell(row,sc).value
                if isinstance(v,str) and v and not v.startswith('='):
                    out.append({'rid':f'xlsx:{sn}:{row}:{sc}','text':v,'key':str(ws.cell(row,ic).value or '') if ic else '', 'meta':{'sheet':sn,'row':row,'source_col':sc}})
        return out
    if fmt == 'json':
        data=json.loads(path.read_text(encoding=opts.get('encoding','utf-8'))); keys=set(opts.get('translatable_keys') or [])
        out=[]
        def walk(obj,p='$'):
            if isinstance(obj,dict):
                for k,v in obj.items():
                    q=f'{p}.{k}'
                    if isinstance(v,str) and (not keys or k in keys): out.append({'rid':q,'text':v,'key':k,'meta':{'path':q}})
                    else: walk(v,q)
            elif isinstance(obj,list):
                for i,v in enumerate(obj): walk(v,f'{p}[{i}]')
        walk(data); return out
    if fmt == 'txt':
        enc=opts.get('encoding','utf-8'); 
        with path.open('r',encoding=enc,newline='') as _f: raw=_f.read()
        lines=raw.splitlines(keepends=True); mode=opts.get('txt_mode','whole_line'); rx=re.compile(opts['text_regex']) if mode=='regex' and opts.get('text_regex') else None; out=[]
        for i,line in enumerate(lines,1):
            body=line.rstrip('\r\n')
            if rx:
                m=rx.search(body)
                if not m: continue
                text=m.groupdict().get('text') if 'text' in m.groupdict() else (m.group(1) if m.groups() else m.group(0))
            else: text=body
            if text: out.append({'rid':f'line:{i}','text':text,'key':'','meta':{'line':i}})
        return out
    if fmt == 'po':
        import polib
        po=polib.pofile(str(path)); out=[]
        for i,e in enumerate(po):
            if e.obsolete or not e.msgid: continue
            out.append({'rid':f'po:{i}','text':(e.msgstr if target and e.msgstr else e.msgid),'key':e.msgctxt or '', 'meta':{'index':i}})
        return out
    if fmt == 'ini':
        enc=opts.get('encoding','utf-8'); out=[]; rx=re.compile(r'^(\s*([^#;][^=:#]*?)\s*[=:]\s*)(.*?)(\r?\n)?$')
        with path.open('r',encoding=enc,newline='') as _f: _lines=_f.read().splitlines(keepends=True)
        for i,line in enumerate(_lines,1):
            m=rx.match(line)
            if m and m.group(3).strip(): out.append({'rid':f'ini:{i}','text':m.group(3),'key':m.group(2).strip(),'meta':{'line':i}})
        return out
    if fmt == 'xml':
        from lxml import etree
        parser=etree.XMLParser(remove_blank_text=False,strip_cdata=False,recover=False)
        tree=etree.parse(str(path),parser); tags=set(opts.get('translatable_tags') or []); attrs=set(opts.get('translatable_attributes') or []); out=[]
        for el in tree.iter():
            if isinstance(el.tag,str) and el.text and el.text.strip() and (not tags or el.tag in tags):
                out.append({'rid':tree.getpath(el)+':text','text':el.text,'key':el.tag,'meta':{'xpath':tree.getpath(el),'kind':'text'}})
            for a,v in el.attrib.items():
                if v and attrs and a in attrs: out.append({'rid':tree.getpath(el)+':@'+a,'text':v,'key':a,'meta':{'xpath':tree.getpath(el),'kind':'attr','attr':a}})
        return out
    raise ValueError(f'Desteklenmeyen format: {fmt}')


def apply(config: dict, translations: dict[str,str], output_path: str):
    src=Path(config['input_path']); out=Path(output_path); out.parent.mkdir(parents=True,exist_ok=True); opts=config.get('format_options',{}); fmt=infer_format(str(src),config.get('format','auto'))
    def tr(text):
        import hashlib
        return translations.get(hashlib.sha256(text.encode('utf-8')).hexdigest(), text)
    if fmt in ('csv','tsv'):
        enc=opts.get('encoding','utf-8'); delim=_csv_dialect(src,fmt,opts); sf=opts.get('source_field'); tf=opts.get('target_field') or sf; idf=opts.get('id_field')
        with src.open(encoding=enc,newline='') as f: r=csv.DictReader(f,delimiter=delim); fields=list(r.fieldnames or []); rows=list(r)
        if not sf: sf=next((x for x in fields if x != idf),None)
        if tf not in fields:
            if opts.get('allow_add_target_field',False): fields.append(tf)
            else: raise ValueError(f'Hedef sütun yok: {tf}')
        for row in rows: row[tf]=tr(row.get(sf,'') or '')
        newline='\r\n' if b'\r\n' in src.read_bytes() else '\n'
        with out.open('w',encoding=enc,newline='') as f:
            w=csv.DictWriter(f,fieldnames=fields,delimiter=delim,lineterminator=newline,quoting=csv.QUOTE_MINIMAL); w.writeheader(); w.writerows(rows)
        return
    if fmt == 'xlsx':
        import openpyxl
        keep=src.suffix.lower()=='.xlsm'; wb=openpyxl.load_workbook(src,data_only=False,keep_vba=keep); hr=int(opts.get('header_row',1)); sheets=opts.get('sheet_names','*'); names=wb.sheetnames if sheets=='*' else list(sheets)
        for sn in names:
            ws=wb[sn]; sc=_col_index(ws,hr,opts.get('source_column')); tc=_col_index(ws,hr,opts.get('target_column') or opts.get('source_column'))
            for row in range(hr+1,ws.max_row+1):
                v=ws.cell(row,sc).value
                if isinstance(v,str) and v and not v.startswith('='): ws.cell(row,tc).value=tr(v)
        wb.save(out); return
    if fmt == 'json':
        data=json.loads(src.read_text(encoding=opts.get('encoding','utf-8'))); keys=set(opts.get('translatable_keys') or [])
        def walk(obj):
            if isinstance(obj,dict):
                for k,v in list(obj.items()):
                    if isinstance(v,str) and (not keys or k in keys): obj[k]=tr(v)
                    else: walk(v)
            elif isinstance(obj,list):
                for v in obj: walk(v)
        walk(data); out.write_text(json.dumps(data,ensure_ascii=False,indent=opts.get('json_indent',2))+'\n',encoding=opts.get('encoding','utf-8')); return
    if fmt == 'txt':
        enc=opts.get('encoding','utf-8')
        with src.open('r',encoding=enc,newline='') as _f: lines=_f.read().splitlines(keepends=True)
        mode=opts.get('txt_mode','whole_line'); rx=re.compile(opts['text_regex']) if mode=='regex' and opts.get('text_regex') else None; new=[]
        for line in lines:
            ending='\r\n' if line.endswith('\r\n') else ('\n' if line.endswith('\n') else '')
            body=line[:-len(ending)] if ending else line
            if rx:
                m=rx.search(body)
                if m:
                    span=m.span('text') if 'text' in m.groupdict() else (m.span(1) if m.groups() else m.span(0)); old=body[span[0]:span[1]]; body=body[:span[0]]+tr(old)+body[span[1]:]
            elif body: body=tr(body)
            new.append(body+ending)
        
        with out.open('w',encoding=enc,newline='') as _f: _f.write(''.join(new))
        return
    if fmt == 'po':
        import polib
        po=polib.pofile(str(src))
        for e in po:
            if not e.obsolete and e.msgid: e.msgstr=tr(e.msgid)
        po.save(str(out)); return
    if fmt == 'ini':
        enc=opts.get('encoding','utf-8'); rx=re.compile(r'^(\s*([^#;][^=:#]*?)\s*[=:]\s*)(.*?)(\r?\n)?$'); new=[]
        with src.open('r',encoding=enc,newline='') as _f: _lines=_f.read().splitlines(keepends=True)
        for line in _lines:
            m=rx.match(line)
            if m and m.group(3).strip(): new.append(m.group(1)+tr(m.group(3))+(m.group(4) or ''))
            else: new.append(line)
        
        with out.open('w',encoding=enc,newline='') as _f: _f.write(''.join(new))
        return
    if fmt == 'xml':
        from lxml import etree
        parser=etree.XMLParser(remove_blank_text=False,strip_cdata=False,recover=False); tree=etree.parse(str(src),parser); tags=set(opts.get('translatable_tags') or []); attrs=set(opts.get('translatable_attributes') or [])
        for el in tree.iter():
            if isinstance(el.tag,str) and el.text and el.text.strip() and (not tags or el.tag in tags): el.text=tr(el.text)
            for a,v in list(el.attrib.items()):
                if v and attrs and a in attrs: el.attrib[a]=tr(v)
        tree.write(str(out),encoding=tree.docinfo.encoding or 'utf-8',xml_declaration=bool(tree.docinfo.xml_version),pretty_print=False); return
    raise ValueError(f'Desteklenmeyen format: {fmt}')


def structural_validate(config: dict, source_path: str, output_path: str) -> list[str]:
    errs=[]; opts=config.get('format_options',{}); fmt=infer_format(source_path,config.get('format','auto')); s=Path(source_path); o=Path(output_path)
    if not o.exists(): return ['Çıktı dosyası oluşmadı']
    try:
        if fmt in ('csv','tsv'):
            delim=_csv_dialect(s,fmt,opts); enc=opts.get('encoding','utf-8')
            with s.open(encoding=enc,newline='') as f: rs=csv.DictReader(f,delimiter=delim); fs=rs.fieldnames; a=list(rs)
            with o.open(encoding=enc,newline='') as f: ro=csv.DictReader(f,delimiter=delim); fo=ro.fieldnames; b=list(ro)
            if fs!=fo: errs.append(f'CSV/TSV sütunları değişti: {fs} != {fo}')
            if len(a)!=len(b): errs.append(f'Kayıt sayısı değişti: {len(a)} != {len(b)}')
            idf=opts.get('id_field')
            if idf and idf in (fs or []):
                for i,(x,y) in enumerate(zip(a,b),2):
                    if x.get(idf)!=y.get(idf): errs.append(f'{i}: ID/KEY değişti'); break
        elif fmt=='xlsx':
            import openpyxl
            wa=openpyxl.load_workbook(s,data_only=False,read_only=False); wb=openpyxl.load_workbook(o,data_only=False,read_only=False)
            if wa.sheetnames!=wb.sheetnames: errs.append('XLSX sayfa adları/sırası değişti')
            for sn in wa.sheetnames:
                if wa[sn].max_row!=wb[sn].max_row or wa[sn].max_column!=wb[sn].max_column: errs.append(f'XLSX boyutu değişti: {sn}')
        elif fmt=='json': json.loads(o.read_text(encoding=opts.get('encoding','utf-8')))
        elif fmt=='po':
            import polib
            if len(polib.pofile(str(s)))!=len(polib.pofile(str(o))): errs.append('PO entry sayısı değişti')
        elif fmt=='xml':
            from lxml import etree
            etree.parse(str(o))
        elif fmt in ('txt','ini'):
            bs=s.read_bytes(); bo=o.read_bytes()
            if bs.count(b'\n')!=bo.count(b'\n'): errs.append('Fiziksel satır sayısı değişti')
            if (b'\r\n' in bs)!=(b'\r\n' in bo): errs.append('Satır sonu biçimi değişti')
    except Exception as e: errs.append(f'Format doğrulama hatası: {e}')
    return errs
